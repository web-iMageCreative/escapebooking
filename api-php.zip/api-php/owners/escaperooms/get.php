<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: https://dev3.icreative.es'); // Específico
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');


// Manejar preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../shared/Database.php';

function getTokenFromHeader() {
    // Intentar diferentes métodos
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        if (isset($headers['Authorization'])) {
            return str_replace('Bearer ', '', $headers['Authorization']);
        }
    }
    
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        return str_replace('Bearer ', '', $_SERVER['HTTP_AUTHORIZATION']);
    }
    
    // Si no se encuentra el token
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Token de autorización no proporcionado'
    ]);
    exit;
}

$db = new Database();

try {
    $token = getTokenFromHeader();
    $token = base64_decode($token);
    $token = json_decode($token, true);
    $user_id = $token['user_id'];
    
    if (!isset($token) || !isset($user_id)) {
        throw new Exception('Token de autorización no proporcionado: ' . json_encode($token));
    }

    $id = $_GET['id'];
    $params = array('id' => $id);
    $query = "SELECT * FROM escaperooms WHERE id = :id ORDER BY name";
    $escaperoom = $db->fetchSingle($query, $params);

    if (!$escaperoom) {
        throw new Exception('EscapeRoom no encontrado.');
    }

    if ($escaperoom['owner'] != $user_id) {
        throw new Exception('No tienes permiso para acceder a este EscapeRoom.');
    }

    echo json_encode([
        'success' => true,
        'message' => 'Escaperooms cargados.',
        'data' => $escaperoom
    ]);
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

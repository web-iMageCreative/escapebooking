<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://dev2.icreative.es');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');


if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../shared/Database.php';

$db = new Database();

try {

    $idRoom = $_GET['id_room'];
    $dayWeek = $_GET['day_week'];
    $params = array(
        'idRoom' => $idRoom,
        'dayWeek' => $dayWeek
    );

    $query = "SELECT TIME_FORMAT(hour, '%H:%i') AS hour FROM schedule WHERE id_room = :idRoom AND day_week = :dayWeek";

    $getHours = $db->fetchAll($query, $params);

    if (!$getHours) {
        echo json_encode([
            'success' => true,
            'message' => 'No hay horas en este día.',
            'data' => []
        ]);
        exit();
    }

    echo json_encode([
        'success' => true,
        'message' => 'Horario cargado.',
        'data' => $getHours
    ]);

} catch (Exception $e) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
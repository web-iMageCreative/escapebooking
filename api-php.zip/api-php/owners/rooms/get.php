<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: https://dev3.icreative.es'); // Específico
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');


// Manejar preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../shared/Database.php';

$db = new Database();

try {
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        $token = str_replace('Bearer ', '', $headers['Authorization'] ?? '');
        $token = base64_decode($token);
        $token = json_decode($token, true);
        $user_id = $token['user_id'];
    } 
    
    if (!isset($token) || !isset($user_id)) {
        throw new Exception('Token de autorización no proporcionado: ' . json_encode($token));
    }

    $id = $_GET['id'] ?? $_GET['id_room'];
    $params = array('id' => $id);
    $query = "SELECT r.*, e.name AS escaperoom_name, e.owner FROM rooms r JOIN escaperooms e ON r.escaperoom_id = e.id WHERE r.id = :id ORDER BY r.name";
    $room = $db->fetchSingle($query, $params);
    
    if (!$room) {
        throw new Exception('Sala no encontrada.');
    }

    if ($room['owner'] != $user_id) {
        throw new Exception('No tienes permiso para acceder a esta sala.');
    }    
   
    $queryPrice = "SELECT * FROM prices WHERE id_room = :id ORDER BY num_players ASC";
    $prices = $db->fetchAll($queryPrice, $params);

    if ($prices) {
        $room['prices'] = $prices;
    } else {
        $room['prices'] = array();
    }

    $querySchedule = "SELECT *, TIME_FORMAT(hour, '%H:%i') AS strHour FROM schedule WHERE id_room = :id";
    $schedule = $db->fetchAll($querySchedule, $params);

    if ($schedule) {
        $room['schedule'] = $schedule;
    } else {
        $room['schedule'] = array();
    }

    echo json_encode([
        'success' => true,
        'message' => 'Salas cargadas.',
        'data' => $room
    ]);
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}